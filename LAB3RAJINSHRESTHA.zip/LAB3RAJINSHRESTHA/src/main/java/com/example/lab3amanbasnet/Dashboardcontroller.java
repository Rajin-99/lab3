package com.example.lab3amanbasnet;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.io.IOException;

public class Dashboardcontroller {
    @FXML
    private Button adminButton;
    @FXML
    private Button employeeButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button exitButton;

    @FXML
    protected void handleAdminButton() {
        loadScene("Admin.fxml", "Admin Scene");
    }

    @FXML
    protected void handleEmployeeButton() {
        loadScene("Employee.fxml", "Employee Scene");
    }

    @FXML
    protected void handleLogoutButton() {
        loadScene("HelloView.fxml", "Login Scene");
    }

    @FXML
    protected void handleExitButton() {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            Parent sceneRoot = FXMLLoader.load(getClass().getResource(fxmlFile));
            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(sceneRoot));
            stage.show();

            // Close the current stage
            Stage currentStage = (Stage) adminButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
